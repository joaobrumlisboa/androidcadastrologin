package com.example.cadastrologin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SecondActivity : AppCompatActivity() {

    private val usuarios = mutableListOf<Pair<String, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.second_activity)

        val usuarioStrings = intent.getStringArrayListExtra("users")
        if (usuarioStrings != null) {
            usuarios.addAll(usuarioStrings.map {
                val parte = it.split(":")
                Pair(parte[0], parte[1])
            })
        }

        val usuarioEditText = findViewById<EditText>(R.id.editText)
        val senhaEditText = findViewById<EditText>(R.id.editText4)
        val confirmasenhaEditText = findViewById<EditText>(R.id.editText5)
        val registrarButton = findViewById<Button>(R.id.button3)

        registrarButton.setOnClickListener {
            val usuario = usuarioEditText.text.toString()
            val senha = senhaEditText.text.toString()
            val confirmasenha = confirmasenhaEditText.text.toString()

            if (usuario.isNotBlank() && senha.isNotBlank() && confirmasenha.isNotBlank()) {
                if (senha == confirmasenha) {
                    usuarios.add(Pair(usuario, senha))
                    Toast.makeText(this, "Usuário cadastrado com sucesso!", Toast.LENGTH_SHORT).show()


                    val intent = Intent()
                    val usuarioStrings = ArrayList(usuarios.map { "${it.first}:${it.second}" })
                    intent.putStringArrayListExtra("users", usuarioStrings)
                    setResult(RESULT_OK, intent)
                    finish()
                } else {
                    Toast.makeText(this, "Senhas não correspondem!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
            }
        }


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}
